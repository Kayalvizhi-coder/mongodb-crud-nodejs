const { MongoClient } = require("mongodb");

 

/*MONGODB_URI=mongodb://USERNAME:PASSWORD@HOST:PORT/DATABASE*/

 

const uri =
     "mongodb://user_453w24nca:p453w24nca@db01.dbhost.dev:5050/db_453w24nca";
 

const client = new MongoClient(uri);

 

async function main() {

    try {

        await client.connect();

        console.log("Connected to MongoDB");

 

        const db = client.db("db_453w24nca");

 

        const students = db.collection("students");

 

        const student = {

            name: "Nithya",

            rollNo: 101,

            department: "CSE",

            age: 20

        };

 

        const result = await students.insertOne(student);

 

        console.log("Student inserted successfully");

        console.log("Inserted ID:", result.insertedId);

 

    } catch (error) {

        console.log("Error:", error);

 

    } finally {

        await client.close();

    }

}

 

main();
