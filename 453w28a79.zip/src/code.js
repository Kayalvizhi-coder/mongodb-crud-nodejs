const { MongoClient } = require("mongodb");

const uri =
  "mongodb://user_453w24nca:p453w24nca@db01.dbhost.dev:5050/db_453w24nca";
 
const client = new MongoClient(uri);
async function main() {
    try {
        
        await client.connect();
        console.log("Connected to MongoDB");
      
        const db = client.db("db_453vzz3ga");
      
        const products = db.collection("products");
       
        const productData = [
            {
                productId: "P101",
                productName: "Laptop",
                category: "Electronics",
                price: 55000,
                quantity: 10,
                supplier: "Dell"
            },
            {
                productId: "P102",
                productName: "Mouse",
                category: "Electronics",
                price: 800,
                quantity: 25,
                supplier: "Logitech"
            },
            {
                productId: "P103",
                productName: "Keyboard",
                category: "Electronics",
                price: 1500,
                quantity: 20,
                supplier: "HP"
            },
            {
                productId: "P104",
                productName: "Notebook",
                category: "Stationery",
                price: 100,
                quantity: 50,
                supplier: "Classmate"
            },
            {
                productId: "P105",
                productName: "Pen",
                category: "Stationery",
                price: 20,
                quantity: 100,
                supplier: "Reynolds"
            }
        ];
        await products.insertMany(productData);
        console.log("5 products inserted successfully");

        console.log("\n2. Electronics Products:");
        const electronics = await products
            .find({ category: "Electronics" })
            .toArray();
        console.log(electronics);

       
        console.log("\n3. One Product:");
        const oneProduct = await products.findOne({
            productId: "P101"
        });
        console.log(oneProduct);

        
        console.log("\n4. Product Name, Price and Quantity:");
        const productDetails = await products
            .find({})
            .project({
                _id: 0,
                productName: 1,
                price: 1,
                quantity: 1
            })
            .toArray();
        console.log(productDetails);

        
        console.log("\n5. Updating price and quantity:");
        await products.updateOne(
            { productId: "P102" },
            {
                $set: {
                    price: 900,
                    quantity: 30
                }
            }
        );
        console.log("P102 price and quantity updated successfully");

       
        console.log("\n6. Updating product using productId:");
        await products.updateOne(
            { productId: "P103" },
            {
                $set: {
                    productName: "Mechanical Keyboard",
                    supplier: "Lenovo"
                }
            }
        );
        console.log("P103 product updated successfully");

       
        console.log("\n7. Deleting product:");
        await products.deleteOne({
            productId: "P105"
        });
        console.log("P105 deleted successfully");

        console.log("\n8. Final Product Records:");
        const finalProducts = await products.find({}).toArray();
        console.log(finalProducts);
    } catch (error) {
        console.log("Error:", error);
    } finally {
       
        await client.close();
        console.log("\nMongoDB connection closed");
    }
}
main();
 